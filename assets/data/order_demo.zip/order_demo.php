<?php
session_start();

/** URL Setup **/
$orderDemoUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/order_demo.php';
$postbackDemoUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/postback_demo.php';

/** Handle Reset **/
if (isset($_POST['action']) && $_POST['action'] === 'reset') {
    session_destroy();
    header('Location: ' . $orderDemoUrl);
    exit;
}

/** Handle Form Submission **/
if (isset($_POST['submit'])) {
    if (!empty($_POST['affiliate_link']) && !empty($_POST['integration_url']) && !empty($_POST['postback_url'])) {
        $_SESSION['affiliate_link'] = $_POST['affiliate_link'];
        $_SESSION['integration_url'] = rtrim($_POST['integration_url'], '/');
        $_SESSION['postback_url'] = $_POST['postback_url'];

        // Extract af_id from affiliate link
        if (preg_match('/ref\/(.*?)$/', $_POST['affiliate_link'], $matches)) {
            $_SESSION['af_id'] = $matches[1];
        }
    }
}

// Generate Random Order Data
$aff_id = $_SESSION['af_id'] ?? '';
$order_id = 'ORD-' . rand(10000, 99999);
$order_total = number_format(rand(50, 1000) + (rand(0, 100) / 100), 2);
$product_ids = rand(100, 999);

// Available Custom Fields
$customFields = [
    ['city' => 'New York'],
    ['countryCode' => 'US'],
    ['timezone' => 'America/New_York'],
    ['ip' => '127.0.0.1'],
    ['id' => $order_id]
];

// Store Data in Session for postback_demo.php
$_SESSION['order_data'] = [
    'af_id' => $aff_id,
    'order_id' => $order_id,
    'order_total' => $order_total,
    'product_ids' => $product_ids,
    'customFields' => json_encode($customFields)
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function autoCompleteIntegrationURL() {
            const integrationInput = document.getElementById('integration_url');
            const integrationPath = '/integration/addOrder';
            if (!integrationInput.value.endsWith(integrationPath)) {
                integrationInput.value = integrationInput.value.replace(/\/$/, '') + integrationPath;
            }
        }
    </script>
</head>
<body class="bg-light">
<div class="container my-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3 class="mb-0">Order Demo</h3>
        </div>
        <div class="card-body">
            <?php if (!isset($_SESSION['affiliate_link']) || !isset($_SESSION['integration_url'])): ?>
            <form method="post" class="mb-4">
                <div class="mb-3">
                    <label class="form-label fw-bold">1. Affiliate Campaign Link:</label>
                    <input type="text" name="affiliate_link" class="form-control" required
                           value="<?= htmlspecialchars($_SESSION['affiliate_link'] ?? '') ?>"
                           placeholder="http://localhost/affscript/ref/[your-ref-code]">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">2. Integration Base URL:</label>
                    <input type="text" name="integration_url" id="integration_url" class="form-control" required
                           value="<?= htmlspecialchars($_SESSION['integration_url'] ?? '') ?>"
                           placeholder="http://localhost/affscript"
                           onblur="autoCompleteIntegrationURL()">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">3. Campaign Postback URL:</label>
                    <input type="text" name="postback_url" class="form-control" required
                           value="<?= htmlspecialchars($_SESSION['postback_url'] ?? '') ?>"
                           placeholder="Paste the Postback URL with your selected parameters">
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Save Settings</button>
            </form>
            <?php else: ?>
            <table class="table table-bordered">
                <tr><th>Affiliate Campaign Link</th><td><?= htmlspecialchars($_SESSION['affiliate_link']); ?></td></tr>
                <tr><th>Integration URL</th><td><?= htmlspecialchars($_SESSION['integration_url']); ?></td></tr>
                <tr><th>Campaign Postback URL</th><td><?= htmlspecialchars($_SESSION['postback_url']); ?></td></tr>
            </table>
            <a href="<?= $postbackDemoUrl; ?>" class="btn btn-success">Process Postback</a>
            <form method="post" class="d-inline">
                <button type="submit" name="action" value="reset" class="btn btn-warning">Edit Settings</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>