<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Postback Demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php
session_start();

/** URL Setup **/
// Base URL dynamically fetched from the session
$affiliateBaseUrl = $_SESSION['integration_url'] ?? 'http://localhost/aff/aff-dev';

// Location of the Order Demo and Postback Demo files (testing environment)
$testingBaseUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']);
$orderDemoUrl = $testingBaseUrl . '/order_demo.php';
$postbackDemoUrl = $testingBaseUrl . '/postback_demo.php';

/** Check Session Data **/
if (!isset($_SESSION['postback_url']) || !isset($_SESSION['order_data'])) {
    die('<div class="container mt-5"><div class="alert alert-danger">Missing required session data. Please return to the order demo.</div></div>');
}

// Retrieve postback URL and order data from the session
$postbackUrl = $_SESSION['postback_url'];
$orderData = $_SESSION['order_data'];

// Define all possible placeholder values
$placeholderValues = [
    '[CITY]' => 'New York',
    '[REGIONCODE]' => 'NY',
    '[REGIONNAME]' => 'New York',
    '[COUNTRYCODE]' => 'US',
    '[COUNTRYNAME]' => 'United States',
    '[CONTINENTNAME]' => 'North America',
    '[TIMEZONE]' => 'America/New_York',
    '[CURRENCYCODE]' => 'USD',
    '[CURRENCYSYMBOL]' => '$',
    '[IP]' => '127.0.0.1',
    '[TYPE]' => 'sale',
    '[ID]' => $orderData['order_id']
];

// Use the affiliate base URL for integration
$baseUrl = $affiliateBaseUrl . '/integration/addOrder';

// Required parameters for order processing
$requestParams = [
    'af_id' => $orderData['af_id'],
    'order_id' => $orderData['order_id'],
    'order_total' => $orderData['order_total'],
    'order_currency' => 'USD',
    'product_ids' => $orderData['product_ids'],
    'script_name' => 'general_integration',
    'base_url' => base64_encode($orderDemoUrl),
    'current_page_url' => base64_encode($postbackDemoUrl)
];

// Parse original URL parameters
$query = parse_url($postbackUrl, PHP_URL_QUERY);
if ($query) {
    parse_str($query, $params);

    // Create customFields array from the parameters in the URL
    $customFields = [];
    foreach ($params as $key => $value) {
        // Skip script_name parameter
        if ($key === 'script_name') continue;

        // Check if it's a dynamic parameter (placeholder)
        if (isset($placeholderValues[$value])) {
            $requestParams[$key] = $placeholderValues[$value];
            $fieldKey = strtolower($key);
            $customFields[] = [$fieldKey => $placeholderValues[$value]];
        }
        // If it's a static parameter, add it as is
        else if ($value !== 'general_integration') {
            $requestParams[$key] = $value;
            $fieldKey = strtolower($key);
            $customFields[] = [$fieldKey => $value];
        }
    }

    // Add customFields to request parameters if we have any
    if (!empty($customFields)) {
        $requestParams['customFields'] = json_encode($customFields);
    }
}

// Build final URL
$finalUrl = $baseUrl . '?' . http_build_query($requestParams);
?>

<div class="container my-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3 class="mb-0">Postback Processing</h3>
        </div>
        <div class="card-body">
            <h5>Original Postback URL:</h5>
            <div class="bg-light p-3 rounded mb-4">
                <code class="text-break"><?php echo htmlspecialchars($postbackUrl); ?></code>
            </div>

            <h5>Final URL with Replaced Values:</h5>
            <div class="bg-light p-3 rounded mb-4">
                <code class="text-break"><?php echo htmlspecialchars($finalUrl); ?></code>
            </div>

            <h5>Request Parameters:</h5>
            <div class="bg-light p-3 rounded mb-4">
                <pre><?php print_r($requestParams); ?></pre>
            </div>

            <h5>Custom Fields:</h5>
            <div class="bg-light p-3 rounded mb-4">
                <pre><?php isset($requestParams['customFields']) ? print_r(json_decode($requestParams['customFields'], true)) : print_r([]); ?></pre>
            </div>

            <h5>Response:</h5>
            <div class="bg-light p-3 rounded">
                <?php
                // Send the actual postback request
                $ch = curl_init();
                curl_setopt_array($ch, [
                    CURLOPT_URL => $finalUrl,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_TIMEOUT => 30
                ]);

                $response = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $error = curl_error($ch);
                curl_close($ch);

                echo "<strong>HTTP Status:</strong> $httpCode<br>";
                if ($error) {
                    echo "<strong>Error:</strong> " . htmlspecialchars($error) . "<br>";
                }
                echo "<strong>Response:</strong> " . htmlspecialchars($response);
                ?>
            </div>
        </div>
        <div class="card-footer">
            <a href="<?= htmlspecialchars($orderDemoUrl); ?>" class="btn btn-primary">Back to Order Demo</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>