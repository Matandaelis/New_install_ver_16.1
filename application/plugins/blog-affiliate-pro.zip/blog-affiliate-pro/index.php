<?php
/*
Plugin Name: Blog Affiliate Pro
Plugin URI: https://yourwebsite.com/blog-affiliate-pro
Description: Blog Affiliate Pro for paid content integration.
Version: 1.0.0
Author: Your Name
Author URI: https://yourwebsite.com/
Text Domain: blog-affiliate-pro
*/

function blog_affi_action_links($links) {
    $links = array_merge(array('<a href="' . esc_url(admin_url('/options-general.php?page=blog_affi_settings_plugin')) . '">' . __('Settings', 'textdomain') . '</a>'), $links);
    return $links;
}
add_action('plugin_action_links_' . plugin_basename(__FILE__), 'blog_affi_action_links');

function blog_affi_settings_page() {
    add_options_page('Blog Affi Settings', 'Blog Affi Settings', 'manage_options', 'blog_affi_settings_plugin', 'blog_affi_settings_page_fun');
}
add_action('admin_menu', 'blog_affi_settings_page');

function blog_affi_settings_page_fun() {
    include "option.php";
}

add_action('init', 'blog_affi_init_fun');
function blog_affi_init_fun() {
    $blog_affi_plugin_option = (int)get_option('blog_affi_plugin_option');
    if ($blog_affi_plugin_option) {
        add_action('wp_head', 'blog_affi_wp_head_fun', 10);
        add_action('the_content', 'blog_affi_content_filter');
        add_action('add_meta_boxes', 'blog_affi_add_meta_box');
        add_action('save_post', 'blog_affi_save_meta_box_data');
    }
}

function blog_affi_wp_head_fun() {
    ?>
    <!-- <script type="text/javascript" src="__baseurl__integration/script"></script> -->
    <script type="text/javascript" src="http://localhost/aff/aff-dev/integration/script"></script>
    <?php
}

function blog_affi_content_filter($content) {
    global $post;
    $access_level = get_post_meta($post->ID, '_blog_affi_access', true);

    if ($access_level === 'paid' && !blog_affi_user_has_access()) {
        return blog_affi_get_paywall_content();
    }

    return $content;
}

function blog_affi_user_has_access() {
    // TODO: Implement check with your main script
    return false;
}

function blog_affi_get_paywall_content() {
    return '<div class="paywall">This content is for paid members only. <a href="#">Subscribe now</a> to access.</div>';
}

function blog_affi_add_meta_box() {
    add_meta_box(
        'blog_affi_meta_box',
        'Blog Affiliate Settings',
        'blog_affi_meta_box_callback',
        'post',
        'side',
        'high'
    );
}

function blog_affi_meta_box_callback($post) {
    wp_nonce_field('blog_affi_save_meta_box_data', 'blog_affi_meta_box_nonce');
    $value = get_post_meta($post->ID, '_blog_affi_access', true);
    ?>
    <p>
        <label for="blog_affi_access_field">Access Level:</label>
        <select name="blog_affi_access_field" id="blog_affi_access_field">
            <option value="free" <?php selected($value, 'free'); ?>>Free</option>
            <option value="paid" <?php selected($value, 'paid'); ?>>Paid</option>
        </select>
    </p>
    <?php
}

function blog_affi_save_meta_box_data($post_id) {
    if (!isset($_POST['blog_affi_meta_box_nonce']) || !wp_verify_nonce($_POST['blog_affi_meta_box_nonce'], 'blog_affi_save_meta_box_data')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['blog_affi_access_field'])) {
        update_post_meta($post_id, '_blog_affi_access', sanitize_text_field($_POST['blog_affi_access_field']));
    }
}

function blog_affi_track_view() {
    global $post;
    
    if (!is_single() || !is_user_logged_in()) {
        return;
    }

    $access_level = get_post_meta($post->ID, '_blog_affi_access', true);
    
    if ($access_level !== 'paid') {
        return;
    }

    $ipaddress = $_SERVER['REMOTE_ADDR'];

    $viewData = array(
        "post_id"     => $post->ID,
        "af_id"       => isset($_COOKIE["af_id"]) ? $_COOKIE["af_id"] : null,
        "ip"          => $ipaddress,
        "base_url"    => base64_encode(get_site_url()),
        "script_name" => "blog_affiliate",
    );

    call_affiliate_api('integration/addBlogView', $viewData);
}
add_action('wp', 'blog_affi_track_view');

if (!function_exists('call_affiliate_api')) {
    function call_affiliate_api($endpoint, $data) {
        global $wp;
        $data['current_page_url'] = base64_encode(home_url($wp->request));
        $context_options = stream_context_create(array(
            'http' => array(
                'method' => "GET",
                'header' => "User-Agent: " . $_SERVER['HTTP_USER_AGENT'] . "\r\n" . "Referer: " . $data['current_page_url'] . "\r\n"
            )
        ));
        //file_get_contents("__baseurl__{$endpoint}?" . http_build_query($data), false, $context_options);
        file_get_contents("http://localhost/aff/aff-dev/{$endpoint}?" . http_build_query($data), false, $context_options);
    }
}