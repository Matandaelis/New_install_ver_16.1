<?php 
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['blog_affi_plugin_option'])) update_option('blog_affi_plugin_option', $_POST['blog_affi_plugin_option']);
}
$blog_affi_plugin_option = (int)get_option('blog_affi_plugin_option');
?>
<div class="wrap">
    <h2>Blog Affiliate Pro Settings</h2>
    <?php settings_errors(); ?>
    <form method="post" action="options-general.php?page=blog_affi_settings_plugin">
        <table class="form-table">
            <tr valign="top">
                <th scope="row" class="textleft"><label for="blog_affi_plugin_option">Plugin Status</label></th>
                <td>
                    <select name="blog_affi_plugin_option" id="blog_affi_plugin_option" class="form-control" required="required">
                        <option value="1" <?php echo $blog_affi_plugin_option ? 'selected="selected"' : ''  ?>>Enable</option>
                        <option value="0" <?php echo !$blog_affi_plugin_option ? 'selected="selected"' : ''  ?>>Disabled</option>
                    </select>
                </td>
            </tr>
        </table>
        <?php submit_button(); ?>
    </form>
</div>